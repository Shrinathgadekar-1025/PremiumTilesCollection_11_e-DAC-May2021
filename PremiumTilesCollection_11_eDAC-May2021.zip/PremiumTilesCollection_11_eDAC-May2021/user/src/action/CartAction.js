import axios from 'axios'
import {
  CART_ADD_FAIL,
  CART_ADD_REQUEST,
  CART_ADD_SUCCESS,
  CART_FETCH_FAIL,
  CART_FETCH_REQUEST,
  CART_FETCH_SUCCESS,
  CART_ITEM_INCREASE_FAIL,
  CART_ITEM_INCREASE_REQUEST,
  CART_ITEM_INCREASE_SUCCESS,
  CART_ITEM_REDUCE_FAIL,
  CART_ITEM_REDUCE_REQUEST,
  CART_ITEM_REDUCE_SUCCESS,
  CART_ORDER_FAIL,
  CART_ORDER_REQUEST,
  CART_ORDER_SUCCESS,
} from '../constants/CartConstants'

export const CartAddFunc = (uSerialNo, pSerialNo) => {
  return (dispatch) => {
    dispatch({
      type: CART_ADD_REQUEST,
    })

    const body = {
      uSerialNo,
      pSerialNo,
    }

    const url = 'http://localhost:6110/backend/user/cart/add-cart'

    axios
      .post(url, body)
      .then((response) => {
        dispatch({
          type: CART_ADD_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: CART_ADD_FAIL,
          payload: error,
        })
      })
  }
}

export const CartFetchFunc = () => {
  return (dispatch) => {
    dispatch({
      type: CART_FETCH_REQUEST,
    })

    let uSerialNo = sessionStorage.getItem('id')

    const body = {
      uSerialNo: uSerialNo,
    }

    const url = 'http://localhost:6110/backend/user/cart/get-carts'

    axios
      .put(url, body)
      .then((response) => {
        dispatch({
          type: CART_FETCH_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: CART_FETCH_FAIL,
          payload: error,
        })
      })
  }
}

export const CartItemReduceFunc = (id) => {
  return (dispatch) => {
    dispatch({
      type: CART_ITEM_REDUCE_REQUEST,
    })

    const url = 'http://localhost:6110/backend/user/cart/reduce-quantity'

    const body = {
      id,
    }
    axios
      .put(url, body)
      .then((response) => {
        dispatch({
          type: CART_ITEM_REDUCE_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: CART_ITEM_REDUCE_FAIL,
          payload: error,
        })
      })
  }
}

export const CartItemIncreaseFunc = (id, amount) => {
  return (dispatch) => {
    dispatch({
      type: CART_ITEM_INCREASE_REQUEST,
    })

    const url = 'http://localhost:6110/backend/user/cart/increase-quantity'
    const body = {
      id,
      amount,
    }
    axios
      .put(url, body)
      .then((response) => {
        dispatch({
          type: CART_ITEM_INCREASE_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: CART_ITEM_INCREASE_FAIL,
          payload: error,
        })
      })
  }
}

export const CartOrderFunc = () => {
  return (dispatch) => {
    dispatch({
      type: CART_ORDER_REQUEST,
    })

    const url = 'http://localhost:6110/backend/user/cart/order-product'
    let uSerialNo = sessionStorage.getItem('id')
    const body = {
      uSerialNo,
    }
    axios
      .put(url, body)
      .then((response) => {
        dispatch({
          type: CART_ORDER_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: CART_ORDER_FAIL,
          payload: error,
        })
      })
  }
}
