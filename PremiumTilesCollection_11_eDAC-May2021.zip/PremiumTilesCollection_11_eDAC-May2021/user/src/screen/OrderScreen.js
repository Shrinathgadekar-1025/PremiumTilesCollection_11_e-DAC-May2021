import { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import { useSelector } from 'react-redux'
import { useHistory, useLocation } from 'react-router'
import { CartOrderFunc } from '../action/CartAction'
import '../css/Order.css'

const OrderScreen = (props) => {
  const [counter, setCounter] = useState(true)
  const [payment, setPayment] = useState(0)
  const [upayment, setUpayment] = useState(0)
  const [orderPlaced, setOrderPlaced] = useState(false)

  const CartOrder = useSelector((store) => store.CartOrder)

  const { response, loading, error } = CartOrder

  const location = useLocation()
  const history = useHistory()
  const dispatch = useDispatch()

  const paymentFunc = () => {
    console.log(payment)
    console.log(upayment)
    if (payment !== parseInt(upayment)) {
      alert('please enter the correct amount ' + payment.toString())
      setUpayment(null)
    } else {
      if (window.confirm('are u sure')) {
        setOrderPlaced(true)
        dispatch(CartOrderFunc())
      }
    }
  }
  useEffect(() => {
    if (counter) {
      setPayment(location.state.value)
    }

    if (response && response.status === 'success' && orderPlaced) {
      setOrderPlaced(false)
      history.push('/home')
      alert('order placed successfully')
    } else if (response && response.status === 'error' && orderPlaced) {
      setOrderPlaced(false)
      alert(response.data)
    } else if (error && orderPlaced) {
      setOrderPlaced(false)
      alert(error)
    }
  }, [response, loading, error])

  return (
    <div className="boxOrder">
      <h3 style={{ textAlign: 'center' }}>Pay</h3>
      {payment !== 0 && (
        <div>
          <div style={{ marginTop: '10px' }} className="form-group">
            <label
              style={{ marginLeft: '10px', marginBottom: '5px' }}
              className="label1"
              htmlFor="payment">
              Payment
            </label>
            <input
              onChange={(e) => {
                setUpayment(e.target.value)
              }}
              type="number"
              id="payment"
              className="form-control"
              placeholder={'enter the amount  ' + payment.toString()}
              required
            />
          </div>
          <div style={{ marginTop: '20px' }}>
            <button
              onClick={paymentFunc}
              style={{ marginLeft: '10px' }}
              className="btn btn-outline-success"
              type="button">
              pay
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export default OrderScreen
