import { useEffect } from 'react'
import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useHistory } from 'react-router-dom'
import { signIn } from '../action/OwnerAction'

import '../css/signin.css'

const SigninScreen = (props) => {
  const [email, setEmail] = useState('')
  const [pwd, setPwd] = useState('')
  const [dataSend, setDataSend] = useState(false)

  const OwnerSignIn = useSelector((store) => store.OwnerSignIn)

  const { loading, error, response } = OwnerSignIn

  const dispatch = useDispatch()

  const history = useHistory()

  const SignIn = () => {
    setDataSend(true)
    dispatch(signIn(email, pwd))
  }

  const ForgetPasswordFunc = () => {
    history.push('/forget-password')
  }

  const SignUp = () => {
    history.push('/signup')
  }

  useEffect(() => {
    if (response && response.status === 'success' && dataSend) {
      setDataSend(false)
      sessionStorage.setItem('email', response.data.email)
      sessionStorage.setItem('id', response.data.serialNo)
      history.push('/home')
    } else if (response && response.status === 'error' && dataSend) {
      setDataSend(false)
      alert(response.data)
    } else if (error && dataSend) {
      setDataSend(false)
      alert(error)
    }
  }, [loading, response, error])

  return (
    <div className="col-md-4 box1">
      <h3 style={{ textAlign: 'center' }}>Login</h3>
      <div style={{ marginTop: '10px' }} className="form-group">
        <label
          style={{ marginLeft: '10px', marginBottom: '5px' }}
          className="label1"
          htmlFor="email">
          email
        </label>
        <input
          onChange={(e) => {
            setEmail(e.target.value)
          }}
          type="email"
          id="email"
          className="form-control"
          placeholder="enter the email address"
          required
        />
      </div>
      <div style={{ marginTop: '10px' }} className="form-group">
        <label
          style={{ marginLeft: '10px', marginBottom: '5px' }}
          className="label1"
          htmlFor="password">
          password
        </label>
        <input
          onChange={(e) => {
            setPwd(e.target.value)
          }}
          type="password"
          id="password"
          className="form-control"
          placeholder="enter the password"
          required
        />
      </div>
      <div className="d-grid gap-2" style={{ marginTop: '20px' }}>
        <button
          onClick={SignIn}
          style={{ marginBottom: '10px' }}
          className="btn btn-success"
          type="button">
          Login
        </button>
        <button onClick={SignUp} className="btn btn-primary" type="button">
          Signup
        </button>
      </div>
      <div style={{ marginTop: '20px' }}>
        <button
          onClick={ForgetPasswordFunc}
          type="button"
          className="btn btn-link float-end">
          Forgot Password
        </button>
      </div>
    </div>
  )
}

export default SigninScreen
