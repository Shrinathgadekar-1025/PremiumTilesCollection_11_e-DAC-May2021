import { applyMiddleware, createStore } from 'redux'
import { combineReducers } from 'redux'
import { composeWithDevTools } from 'redux-devtools-extension'
import logger from 'redux-logger'
import thunk from 'redux-thunk'
import {
  CartAddReducer,
  CartFetchReducer,
  CartItemIncreaseReducer,
  CartItemReduceReducer,
  CartOrderReducer,
} from './reducer/CartReducer'
import { HomeProductFetchReducer } from './reducer/HomeReducer'
import {
  ownerOtpRequestReducer,
  ownerPasswordUpdateReducer,
  ownerProfilePicRequestReducer,
  ownerProfilePicUploadReducer,
  ownerProfileRequestReducer,
  ownerProfileUpdateRequestReducer,
  ownerSignInReducer,
  ownerSignupReducer,
} from './reducer/OwnerReducer'
import {
  TileAddReducer,
  TileImageUploadReducer,
  TilesDeleteReducer,
  TilesMaterialFetchReducer,
  TilesTypeFetchReducer,
} from './reducer/TileReducer'

const reducers = combineReducers({
  OwnerSignUp: ownerSignupReducer,
  OwnerSignIn: ownerSignInReducer,
  OwnerProfilePicupload: ownerProfilePicUploadReducer,
  OwnerProfileRequest: ownerProfileRequestReducer,
  OwnerProfilePicRequest: ownerProfilePicRequestReducer,
  OwnerProfileUpdate: ownerProfileUpdateRequestReducer,
  OwnerOtp: ownerOtpRequestReducer,
  OwnerPassReset: ownerPasswordUpdateReducer,
  TileAdd: TileAddReducer,
  TileImageUpload: TileImageUploadReducer,
  TilesTypeFetch: TilesTypeFetchReducer,
  TilesMaterialFetch: TilesMaterialFetchReducer,
  TileDelete: TilesDeleteReducer,
  CartAdd: CartAddReducer,
  CartFetch: CartFetchReducer,
  CartItemIncrease: CartItemIncreaseReducer,
  CartItemReduce: CartItemReduceReducer,
  CartOrder: CartOrderReducer,
  HomeProductFetch: HomeProductFetchReducer,
})

const store = createStore(
  reducers,
  composeWithDevTools(applyMiddleware(logger, thunk))
)

export default store
