import { useEffect } from 'react'
import { useState } from 'react'
import { Modal } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import { useHistory } from 'react-router-dom'
import { getProfile, getProfilePic, logout } from '../action/OwnerAction'
import ModelBody from './ModelBody'

const Example = (props) => {
  const [profileFetch, setProfileFetch] = useState(true)
  const OwnerProfileRequest = useSelector((store) => store.OwnerProfileRequest)

  const OwnerProfilePicRequest = useSelector(
    (store) => store.OwnerProfilePicRequest
  )

  const { loading, error, response } = OwnerProfileRequest

  const {
    loading: loading1,
    error: error1,
    response: response1,
  } = OwnerProfilePicRequest

  const dispatch = useDispatch()

  const history = useHistory()

  const [data, setData] = useState()
  const [profilePic, setProfilePic] = useState(null)

  const LogOut = () => {
    if (window.confirm('you wanna logout')) {
      dispatch(logout())
      history.push('/signin')
    }
  }

  const EditClick = () => {
    setShow(false)
    const myData = {
      data,
      profilePic,
    }
    history.push('/edit-profile', myData)
  }

  const getProfiler = () => {
    console.log('in getProfiler')
    setProfileFetch(true)
    dispatch(getProfile())
  }

  const requestProfilePic = () => {
    console.log('in requestProfilePic')
    dispatch(getProfilePic())
  }
  const [show, setShow] = useState(false)

  const handleClose = () => setShow(false)
  const handleShow = () => {
    getProfiler()
    setShow(true)
  }

  useEffect(() => {
    if (response && response.status === 'success' && profileFetch) {
      console.log(response.data)
      setData(response.data)
      setProfileFetch(false)
      requestProfilePic()
    } else if (response && response.status === 'error') {
      alert(response.error)
    } else if (error) {
      alert(error)
    }

    if (response1) {
      console.log('image successfully')
      console.log(typeof response1.data)
      console.log(response1)
      const byteCharacters = atob(response1.data)
      const byteNumbers = new Array(byteCharacters.length)
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i)
      }
      const byteArray = new Uint8Array(byteNumbers)
      const blob = new Blob([byteArray], { type: 'image/*' })

      setProfilePic(blob)
    } else if (response1 && response1.status === 'error') {
      alert(response1.data.data)
    } else if (error1) {
      alert(error1)
    }
  }, [loading, response, error, loading1, response1, error1])

  return (
    <div>
      <span onClick={handleShow}>
        <i className="fas fa-user"></i>
      </span>
      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}>
        <Modal.Header closeButton>
          <Modal.Title>Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {data != null && profilePic != null && (
            <ModelBody userInfo={data} profilePic={profilePic} />
          )}
        </Modal.Body>
        <Modal.Footer>
          <button
            type="button"
            onClick={LogOut}
            className="btn btn-outline-dark "
            style={{ marginRight: '330px' }}>
            Logout
          </button>
          <button onClick={EditClick} className="btn btn-outline-info ">
            Edit
          </button>
        </Modal.Footer>
      </Modal>
    </div>
  )
}

export default Example
