const CartTileModalBody = (props) => {
  return (
    <div>
      {props.cart && (
        <img
          width="200px"
          height="200px"
          src={URL.createObjectURL(props.cart.blob)}
        />
      )}
      {props.cart && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Type ::{' '}
          </span>{' '}
          {props.cart.cart.tile.productType}
        </div>
      )}
      {props.cart && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Material ::{' '}
          </span>{' '}
          {props.cart.cart.tile.productMaterial}
        </div>
      )}
      {props.cart && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Base ::{' '}
          </span>{' '}
          {props.cart.cart.tile.productBase}
        </div>
      )}
      {props.cart && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Size ::{' '}
          </span>{' '}
          {props.cart.cart.tile.productSize}
        </div>
      )}

      {props.cart && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Finishing ::{' '}
          </span>{' '}
          {props.cart.cart.tile.productFinishing}
        </div>
      )}
      {props.cart && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Price ::{' '}
          </span>{' '}
          {props.cart.cart.tile.price}
        </div>
      )}
      {props.cart && (
        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
            {' '}
            Total Price ::{' '}
          </span>{' '}
          {props.cart.cart.tile.price * props.cart.cart.count}
        </div>
      )}
    </div>
  )
}

export default CartTileModalBody
