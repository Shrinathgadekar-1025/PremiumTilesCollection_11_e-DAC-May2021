import {
  BrowserRouter as Router,
  Redirect,
  Route,
  Switch,
} from 'react-router-dom'
import './App.css'
import Header from './components/Header'
import AddTilesScreen from './screen/AddTilesScreen'
import CustomOrder from './screen/CustomOrder'
import ForgetPassword from './screen/ForgetPassword'
import HomeScreen from './screen/HomeScreen'
import OrderScreen from './screen/OrderScreen'
import ProductMaterialTilesScreen from './screen/ProductMaterialTilesScreen'
import ProductTypeTilesScreen from './screen/ProductTypeTilesScreen'
import SigninScreen from './screen/SigninScreen '
import SignUpScreen from './screen/SignUpScreen'
import UpdateProfileScreen from './screen/UpdateProfileScreen'

function App() {
  return (
    <div>
      <Router>
        <Header />
        <div>
          <Switch>
            <Route exact path="/" render={() => <Redirect to="/signin" />} />
            <Route path="/home" component={HomeScreen} />
            <Route path="/signin" component={SigninScreen} />
            <Route path="/signup" component={SignUpScreen} />
            <Route path="/forget-password" component={ForgetPassword} />
            <Route path="/add-tile" component={AddTilesScreen} />
            <Route path="/edit-profile" component={UpdateProfileScreen} />
            <Route path="/product-type" component={ProductTypeTilesScreen} />
            <Route path="/orders" component={OrderScreen} />
            <Route path="/custom-orders" component={CustomOrder} />
            <Route
              Path="/product-material"
              component={ProductMaterialTilesScreen}
            />
            <Route exact path="*" render={() => <Redirect to="/signin" />} />
          </Switch>
        </div>
      </Router>
    </div>
  )
}

export default App
