import {
  TILES_MATERIAL_FETCH_FAIL,
  TILES_MATERIAL_FETCH_REQUEST,
  TILES_MATERIAL_FETCH_SUCCESS,
  TILES_TYPE_FETCH_FAIL,
  TILES_TYPE_FETCH_REQUEST,
  TILES_TYPE_FETCH_SUCCESS,
  TILE_ADD_FAIL,
  TILE_ADD_REQUEST,
  TILE_ADD_SUCCESS,
  TILE_DELETE_FAIL,
  TILE_DELETE_REQUEST,
  TILE_DELETE_SUCCESS,
  TILE_IMAGE_UPLOAD_FAIL,
  TILE_IMAGE_UPLOAD_REQUEST,
  TILE_IMAGE_UPLOAD_SUCCESS,
} from '../constants/TilesConstants'

export const TileAddReducer = (state = {}, action) => {
  switch (action.type) {
    case TILE_ADD_REQUEST:
      return { loading: true }
    case TILE_ADD_SUCCESS:
      return { loading: false, response: action.payload }
    case TILE_ADD_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const TileImageUploadReducer = (state = {}, action) => {
  switch (action.type) {
    case TILE_IMAGE_UPLOAD_REQUEST:
      return { loading: true }
    case TILE_IMAGE_UPLOAD_SUCCESS:
      return { loading: false, response: action.payload }
    case TILE_IMAGE_UPLOAD_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}
export const TilesTypeFetchReducer = (state = {}, action) => {
  switch (action.type) {
    case TILES_TYPE_FETCH_REQUEST:
      return { loading: true }
    case TILES_TYPE_FETCH_SUCCESS:
      return { loading: false, response: action.payload }
    case TILES_TYPE_FETCH_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const TilesMaterialFetchReducer = (state = {}, action) => {
  switch (action.type) {
    case TILES_MATERIAL_FETCH_REQUEST:
      return { loading: true }
    case TILES_MATERIAL_FETCH_SUCCESS:
      return { loading: false, response: action.payload }
    case TILES_MATERIAL_FETCH_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}

export const TilesDeleteReducer = (state = {}, action) => {
  switch (action.type) {
    case TILE_DELETE_REQUEST:
      return { loading: true }
    case TILE_DELETE_SUCCESS:
      return { loading: false, response: action.payload }
    case TILE_DELETE_FAIL:
      return { loading: false, error: action.payload }
    default:
      return state
  }
}
