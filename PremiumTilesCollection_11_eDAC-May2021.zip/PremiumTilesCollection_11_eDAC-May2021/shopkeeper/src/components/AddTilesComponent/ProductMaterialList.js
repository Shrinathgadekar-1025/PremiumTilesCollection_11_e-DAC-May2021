import { Dropdown, DropdownButton } from 'react-bootstrap'

const ProductMaterialList = (props) => {
  const onDropDownSelect = (event) => {
    console.log('hello')
    console.log(event.target.outerText)
    props.onSelectMaterial(event.target.outerText)
  }
  return (
    <DropdownButton
      id="dropdown-variants-secondary"
      variant="secondary"
      title="Product Material">
      <Dropdown.Item
        onClick={(event) => {
          onDropDownSelect(event)
        }}>
        Glazed Vitrified
      </Dropdown.Item>
      <Dropdown.Item
        onClick={(event) => {
          onDropDownSelect(event)
        }}>
        Ceramic
      </Dropdown.Item>
      <Dropdown.Item
        onClick={(event) => {
          onDropDownSelect(event)
        }}>
        Polished Vitrified
      </Dropdown.Item>
    </DropdownButton>
  )
}

export default ProductMaterialList
