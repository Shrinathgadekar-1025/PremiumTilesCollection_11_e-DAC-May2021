import { Dropdown, DropdownButton } from 'react-bootstrap'

const ProductTypeList = (props) => {
  const onDropDownSelect = (event) => {
    console.log('hello')
    console.log(event.target.outerText)
    props.onSelectType(event.target.outerText)
  }
  return (
    <DropdownButton
      id="dropdown-variants-secondary"
      variant="secondary"
      title="Product Type">
      <Dropdown.Item
        onClick={(event) => {
          onDropDownSelect(event)
        }}>
        Wall
      </Dropdown.Item>
      <Dropdown.Item
        onClick={(event) => {
          onDropDownSelect(event)
        }}>
        Floor
      </Dropdown.Item>
    </DropdownButton>
  )
}

export default ProductTypeList
