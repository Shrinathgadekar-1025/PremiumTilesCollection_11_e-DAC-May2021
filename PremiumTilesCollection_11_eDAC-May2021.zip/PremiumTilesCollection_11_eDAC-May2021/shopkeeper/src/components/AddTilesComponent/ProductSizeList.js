import { useState } from 'react'

const ProductSizeList = (props) => {
  const [sizeW] = useState([
    { index: 1, size: '80 X 120 cm' },
    { index: 2, size: '60 X 120 cm' },
    { index: 3, size: '40 X 120 cm' },
    { index: 4, size: '40 X 80 cm' },
    { index: 5, size: '30 X 60 cm' },
    { index: 6, size: '30 X 45 cm' },
    { index: 7, size: '80 X 120 cm' },
    { index: 8, size: '15 X 60 cm' },
    { index: 9, size: '15 X 45 cm' },
    { index: 10, size: '30 X 20 cm' },
  ])
  const [sizeF] = useState([
    { index: 11, size: '100 X 200 cm' },
    { index: 12, size: '120 X 180 cm' },
    { index: 13, size: '29 X 180 cm' },
    { index: 14, size: '120 X 120 cm' },
    { index: 15, size: '80 X 160 cm' },
    { index: 16, size: '80 X 120 cm' },
    { index: 17, size: '60 X 120 cm' },
    { index: 18, size: '20 X 120 cm' },
    { index: 19, size: '100 X 100 cm' },
    { index: 20, size: '80 X 80 cm' },
    { index: 21, size: '40 X 80 cm' },
    { index: 22, size: '13 X 80 cm' },
    { index: 23, size: '60 X 60 cm' },
    { index: 24, size: '30 X 60 cm' },
    { index: 25, size: '15 X 60 cm' },
    { index: 26, size: '40 X 40 cm' },
    { index: 27, size: '30 X 30 cm' },
  ])

  const onListSelect = (event) => {
    console.log('hello')
    console.log(event.target.outerText)
    props.onSelectSize(event.target.outerText)
  }

  return (
    <div>
      <p>
        <button
          className="btn btn-secondary "
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#collapseExample"
          aria-expanded="false"
          aria-controls="collapseExample">
          Size
        </button>
      </p>
      <div className="collapse" id="collapseExample">
        <div className="divContainigULAddTiles list-group">
          {props.type && props.type === 'Wall'
            ? sizeW.map((size) => {
                return (
                  <div
                    key={size.index}
                    className="list-group-item list-group-item-action"
                    onClick={(event) => {
                      onListSelect(event)
                    }}>
                    {size.size}
                  </div>
                )
              })
            : sizeF.map((size) => {
                return (
                  <div
                    key={size.index}
                    className="list-group-item list-group-item-action"
                    onClick={(event) => {
                      onListSelect(event)
                    }}>
                    {size.size}
                  </div>
                )
              })}
        </div>
      </div>
    </div>
  )
}

export default ProductSizeList
