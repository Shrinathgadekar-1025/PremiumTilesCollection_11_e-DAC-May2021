import { useState } from 'react'

const SearchByMaterial = (props) => {
  const [material] = useState([
    { index: 0, material: 'Glazed Vitrified' },
    { index: 1, material: 'Ceramic' },
    { index: 2, material: 'Polished Vitrified' },
  ])
  const onDivSelect = (event) => {
    console.log(event.target.outerText)
    props.onSelectMaterial(event.target.outerText)
  }
  return (
    <div className="productTypeMaterialDiv">
      <div className="divLabel">Search By Material</div>
      {material.map((mat) => {
        return (
          <div
            className="divScroll"
            key={mat.index}
            onClick={(event) => {
              onDivSelect(event)
            }}>
            {mat.material}
          </div>
        )
      })}
    </div>
  )
}

export default SearchByMaterial
