import { Button } from 'bootstrap'
import { useState } from 'react'
import { Modal } from 'react-bootstrap'
import TileModalBody from './TileModalBody'

const TileModal = (props) => {
  const [show, setShow] = useState(false)

  const handleClose = () => setShow(false)
  const handleShow = () => setShow(true)

  const onDeletePress = () => {
    if (window.confirm('are u sure u want to delete the tile')) {
      props.onDeletePress(props.tile.tile.serialNo)
      setShow(false)
    }
  }
  return (
    <>
      {props.tile && (
        <img
          onClick={handleShow}
          className="DisplayTilesImageClass"
          src={URL.createObjectURL(props.tile.blob)}
        />
      )}

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          {props.tile && <Modal.Title>{props.tile.tile.tilesName}</Modal.Title>}
        </Modal.Header>
        <Modal.Body>
          {props.tile && <TileModalBody tile={props.tile} />}
        </Modal.Body>
        <Modal.Footer>
          <button
            onClick={onDeletePress}
            style={{ marginRight: '320px' }}
            className="btn btn-outline-danger">
            Delete
          </button>
          <button className="btn btn-outline-secondary" onClick={handleClose}>
            Close
          </button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default TileModal
