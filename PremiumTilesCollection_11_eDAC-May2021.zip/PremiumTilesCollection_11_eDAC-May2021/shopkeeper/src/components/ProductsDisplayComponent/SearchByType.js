import { useState } from 'react'

const SearchByType = (props) => {
  const [type] = useState([
    { index: 1, type: 'Wall' },
    { index: 2, type: 'Floor' },
  ])

  const onDivSelect = (event) => {
    console.log(event.target.outerText)
    props.onSelectType(event.target.outerText)
  }

  return (
    <div style={{ height: '170px' }} className="productTypeMaterialDiv">
      <div className="divLabel">Search By Type</div>
      {type.map((t) => {
        return (
          <div
            className="divScroll"
            key={t.index}
            onClick={(event) => {
              onDivSelect(event)
            }}>
            {t.type}
          </div>
        )
      })}
    </div>
  )
}

export default SearchByType
