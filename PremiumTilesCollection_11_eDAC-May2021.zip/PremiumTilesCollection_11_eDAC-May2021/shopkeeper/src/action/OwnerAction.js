import axios from 'axios'
import {
  OWNER_OTP_FAIL,
  OWNER_OTP_REQUEST,
  OWNER_OTP_SUCCESS,
  OWNER_PASS_RESET_FAIL,
  OWNER_PASS_RESET_REQUEST,
  OWNER_PASS_RESET_SUCCESS,
  OWNER_PROFILE_FAIL,
  OWNER_PROFILE_PIC_FAIL,
  OWNER_PROFILE_PIC_REQUEST,
  OWNER_PROFILE_PIC_SUCCESS,
  OWNER_PROFILE_PIC_UPLOAD_FAIL,
  OWNER_PROFILE_PIC_UPLOAD_REQUEST,
  OWNER_PROFILE_PIC_UPLOAD_SUCCESS,
  OWNER_PROFILE_REQUEST,
  OWNER_PROFILE_SUCCESS,
  OWNER_PROFILE_UPDATE_FAIL,
  OWNER_PROFILE_UPDATE_REQUEST,
  OWNER_PROFILE_UPDATE_SUCCESS,
  OWNER_SIGNIN_FAIL,
  OWNER_SIGNIN_REQUEST,
  OWNER_SIGNIN_SUCCESS,
  OWNER_SIGNOUT,
  OWNER_SIGNUP_FAIL,
  OWNER_SIGNUP_REQUEST,
  OWNER_SIGNUP_SUCCESS,
} from '../constants/ShopKeeperConstants'

export const signUp = (
  firstName,
  lastName,
  email,
  phone,
  pwd,
  birthDate,
  buildingName,
  colonyName,
  city,
  state,
  pincode
) => {
  return (dispatch) => {
    dispatch({
      type: OWNER_SIGNUP_REQUEST,
    })

    const body = {
      firstName,
      lastName,
      email,
      phone,
      pwd,
      birthDate,
      buildingName,
      colonyName,
      city,
      state,
      pincode,
    }

    const url = 'http://localhost:6110/backend/shop-keeper/signup'
    axios
      .post(url, body)
      .then((response) => {
        dispatch({
          type: OWNER_SIGNUP_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: OWNER_SIGNUP_FAIL,
          payload: error,
        })
      })
  }
}

export const signIn = (email, pwd) => {
  return (dispatch) => {
    dispatch({
      type: OWNER_SIGNIN_REQUEST,
    })

    const body = {
      email,
      pwd,
    }

    const url = 'http://localhost:6110/backend/shop-keeper/login'

    axios
      .post(url, body)
      .then((response) => {
        dispatch({
          type: OWNER_SIGNIN_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: OWNER_SIGNIN_FAIL,
          payload: error,
        })
      })
  }
}

export const logout = () => {
  return (dispatch) => {
    sessionStorage.removeItem('email')
    sessionStorage.removeItem('id')
    dispatch({ type: OWNER_SIGNOUT })
    document.location.href = '/signin'
  }
}
export const profilePicUpload = (file, serialNo) => {
  return (dispatch) => {
    dispatch({
      type: OWNER_PROFILE_PIC_UPLOAD_REQUEST,
    })

    console.log(typeof file)
    // Create an object of formData
    const formData = new FormData()

    // Update the formData object
    formData.append('file', file, file.name)
    const header = {
      headers: {
        'Content-Type': 'multipart/form-data',
        id: serialNo,
      },
    }

    const url = 'http://localhost:6110/backend/shop-keeper/image-upload'

    axios
      .post(url, formData, header)
      .then((response) => {
        dispatch({
          type: OWNER_PROFILE_PIC_UPLOAD_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: OWNER_PROFILE_PIC_UPLOAD_FAIL,
          payload: error,
        })
      })
  }
}

export const getProfile = () => {
  return (dispatch) => {
    dispatch({
      type: OWNER_PROFILE_REQUEST,
    })

    const serialNo = sessionStorage.getItem('id')
    const body = {
      serialNo,
    }

    const url = 'http://localhost:6110/backend/shop-keeper/get-profile'

    axios
      .post(url, body)
      .then((response) => {
        dispatch({
          type: OWNER_PROFILE_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: OWNER_PROFILE_FAIL,
          payload: error,
        })
      })
  }
}

export const getProfilePic = () => {
  return (dispatch) => {
    dispatch({
      type: OWNER_PROFILE_PIC_REQUEST,
    })

    const body = {
      serialNo: sessionStorage.getItem('id'),
    }

    const url = 'http://localhost:6110/backend/shop-keeper/image-download'

    axios
      .put(url, body)
      .then((response) => {
        dispatch({
          type: OWNER_PROFILE_PIC_SUCCESS,
          payload: response,
        })
      })
      .catch((error) => {
        dispatch({
          type: OWNER_PROFILE_PIC_FAIL,
          payload: error,
        })
      })
  }
}

export const UpdateProfile = (
  firstName,
  lastName,
  email,
  phone,
  buildingName,
  colonyName,
  city,
  state,
  pincode
) => {
  return (dispatch) => {
    dispatch({
      type: OWNER_PROFILE_UPDATE_REQUEST,
    })

    let serialNo = sessionStorage.getItem('id')

    const header = {
      headers: {
        id: serialNo,
      },
    }
    const body = {
      firstName,
      lastName,
      email,
      phone,
      buildingName,
      colonyName,
      city,
      state,
      pincode,
    }

    const url = 'http://localhost:6110/backend/shop-keeper/update-profile'
    axios
      .put(url, body, header)
      .then((response) => {
        dispatch({
          type: OWNER_PROFILE_UPDATE_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: OWNER_PROFILE_UPDATE_FAIL,
          payload: error,
        })
      })
  }
}

export const ReqeustOtp = (email) => {
  return (dispatch) => {
    dispatch({
      type: OWNER_OTP_REQUEST,
    })

    const body = {
      email,
    }

    const url = 'http://localhost:6110/backend/shop-keeper/forget-password'

    axios
      .put(url, body)
      .then((response) => {
        dispatch({
          type: OWNER_OTP_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: OWNER_OTP_FAIL,
          payload: error,
        })
      })
  }
}

export const UpdatePassword = (email, otp, pwd) => {
  return (dispatch) => {
    dispatch({
      type: OWNER_PASS_RESET_REQUEST,
    })

    const body = {
      otp,
      email,
      pwd,
    }

    const url = 'http://localhost:6110/backend/shop-keeper/update-password'

    axios
      .put(url, body)
      .then((response) => {
        dispatch({
          type: OWNER_PASS_RESET_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: OWNER_PASS_RESET_FAIL,
          payload: error,
        })
      })
  }
}
