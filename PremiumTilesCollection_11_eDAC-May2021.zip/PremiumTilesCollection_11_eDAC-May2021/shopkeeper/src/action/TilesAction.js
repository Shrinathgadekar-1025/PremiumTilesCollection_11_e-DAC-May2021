import axios from 'axios'
import {
  TILES_MATERIAL_FETCH_FAIL,
  TILES_MATERIAL_FETCH_REQUEST,
  TILES_MATERIAL_FETCH_SUCCESS,
  TILES_TYPE_FETCH_FAIL,
  TILES_TYPE_FETCH_REQUEST,
  TILES_TYPE_FETCH_SUCCESS,
  TILE_ADD_FAIL,
  TILE_ADD_REQUEST,
  TILE_ADD_SUCCESS,
  TILE_DELETE_FAIL,
  TILE_DELETE_REQUEST,
  TILE_DELETE_SUCCESS,
  TILE_IMAGE_UPLOAD_FAIL,
  TILE_IMAGE_UPLOAD_REQUEST,
  TILE_IMAGE_UPLOAD_SUCCESS,
} from '../constants/TilesConstants'

export const TileAddFunc = (
  tilesName,
  productMaterial,
  productType,
  productUse,
  productSize,
  productFinishing,
  price
) => {
  return (dispatch) => {
    dispatch({
      type: TILE_ADD_REQUEST,
    })

    const body = {
      tilesName,
      productMaterial,
      productType,
      productUse,
      productSize,
      productFinishing,
      price,
    }

    // Create an object of formData

    const url = 'http://localhost:6110/backend/shop-keeper/product/addProduct'

    axios
      .post(url, body)
      .then((response) => {
        dispatch({
          type: TILE_ADD_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: TILE_ADD_FAIL,
          payload: error,
        })
      })
  }
}

export const tilePicUpload = (file, serialNo) => {
  return (dispatch) => {
    dispatch({
      type: TILE_IMAGE_UPLOAD_REQUEST,
    })

    // Create an object of formData
    const formData = new FormData()

    // Update the formData object
    formData.append('file', file, file.name)
    const header = {
      headers: {
        id: serialNo,
      },
    }

    const url = 'http://localhost:6110/backend/shop-keeper/product/image-upload'

    axios
      .post(url, formData, header)
      .then((response) => {
        dispatch({
          type: TILE_IMAGE_UPLOAD_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: TILE_IMAGE_UPLOAD_FAIL,
          payload: error,
        })
      })
  }
}

export const FetchTilesType = (type) => {
  return (dispatch) => {
    dispatch({
      type: TILES_TYPE_FETCH_REQUEST,
    })

    const url = 'http://localhost:6110/backend/shop-keeper/product/get-type'
    const body = {
      email: type,
    }
    axios
      .put(url, body)
      .then((response) => {
        dispatch({
          type: TILES_TYPE_FETCH_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: TILES_TYPE_FETCH_FAIL,
          payload: error,
        })
      })
  }
}

export const FetchTilesMaterial = (material) => {
  return (dispatch) => {
    dispatch({
      type: TILES_MATERIAL_FETCH_REQUEST,
    })

    const url = 'http://localhost:6110/backend/shop-keeper/product/get-material'
    const body = {
      email: material,
    }
    axios
      .put(url, body)
      .then((response) => {
        dispatch({
          type: TILES_MATERIAL_FETCH_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: TILES_MATERIAL_FETCH_FAIL,
          payload: error,
        })
      })
  }
}

export const DeleteTileFunc = (serialNo) => {
  return (dispatch) => {
    dispatch({
      type: TILE_DELETE_REQUEST,
    })

    const url = 'http://localhost:6110/backend/shop-keeper/product/delete-tile'
    const body = {
      serialNo,
    }
    axios
      .put(url, body)
      .then((response) => {
        dispatch({
          type: TILE_DELETE_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: TILE_DELETE_FAIL,
          payload: error,
        })
      })
  }
}
