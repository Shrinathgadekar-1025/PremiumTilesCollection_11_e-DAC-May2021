import axios from 'axios'
import {
  CART_CUSTOMIZED_ACCEPT_FAIL,
  CART_CUSTOMIZED_ACCEPT_REQUEST,
  CART_CUSTOMIZED_ACCEPT_SUCCESS,
  CART_CUSTOMIZED_FAIL,
  CART_CUSTOMIZED_REQUEST,
  CART_CUSTOMIZED_SUCCESS,
  CART_DELIVER_FAIL,
  CART_DELIVER_REQUEST,
  CART_DELIVER_SUCCESS,
  CART_ORDER_FAIL,
  CART_ORDER_REQUEST,
  CART_ORDER_SUCCESS,
} from '../constants/CartConstants'

export const CartCustomizedOrderFunc = () => {
  return (dispatch) => {
    dispatch({
      type: CART_CUSTOMIZED_REQUEST,
    })

    const url =
      'http://localhost:6110/backend/shop-keeper/cart/get-pending-request'

    axios
      .get(url)
      .then((response) => {
        dispatch({
          type: CART_CUSTOMIZED_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: CART_CUSTOMIZED_FAIL,
          payload: error,
        })
      })
  }
}

export const CartOrderFunc = () => {
  return (dispatch) => {
    dispatch({
      type: CART_ORDER_REQUEST,
    })

    const url = 'http://localhost:6110/backend/shop-keeper/cart/get-orders'

    axios
      .get(url)
      .then((response) => {
        dispatch({
          type: CART_ORDER_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: CART_ORDER_FAIL,
          payload: error,
        })
      })
  }
}

export const CartDeliveryFunc = (id) => {
  return (dispatch) => {
    dispatch({
      type: CART_DELIVER_REQUEST,
    })

    const url = 'http://localhost:6110/backend/shop-keeper/cart/deliver-product'

    let body = {
      id,
    }
    axios
      .post(url, body)
      .then((response) => {
        dispatch({
          type: CART_DELIVER_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: CART_DELIVER_FAIL,
          payload: error,
        })
      })
  }
}

export const CartAcceptFunc = (id) => {
  return (dispatch) => {
    dispatch({
      type: CART_CUSTOMIZED_ACCEPT_REQUEST,
    })

    const url = 'http://localhost:6110/backend/shop-keeper/cart/accept-product'

    let body = {
      id,
    }
    axios
      .post(url, body)
      .then((response) => {
        dispatch({
          type: CART_CUSTOMIZED_ACCEPT_SUCCESS,
          payload: response.data,
        })
      })
      .catch((error) => {
        dispatch({
          type: CART_CUSTOMIZED_ACCEPT_FAIL,
          payload: error,
        })
      })
  }
}
