package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.UserRepository;
import com.example.demo.pojos.User;



@Service
@Transactional
public class UserServiceImpl implements IUserService {
	
	@Autowired
	private UserRepository userRepo;
	

	
	public UserServiceImpl() {
		System.out.println("in ctor of "+getClass().getName());
	}
	

	@Override
	public User addUser(User u) {
		System.out.println("in method of adding user of userservice "+u.getEmail());

		try {
			return userRepo.save(u);
		} catch ( Exception e) {
			System.out.println("in exception of addUser");
			System.out.println(e.getMessage());
		}
		return null;
	}


	@Override
	public User getUserByEmailAndPwd(String email,String pwd) {
		System.out.println("in method of getuserByEmail of userservice "+email);
		try {
			Optional<User> optional=userRepo.findByEmailAndPwd(email,pwd);
			if(optional.isPresent())
				return optional.get();
		} catch (Exception e) {
			System.out.println("in exception of getUserByEmailAndPwd");
			System.out.println(e.getMessage());
		}
		return null;
	}


	@Override
	public User getUserByEmail(String email) {
		System.out.println("in method of getuserByEmail of userservice "+email);
		try {
			Optional<User> optional=userRepo.findByEmail(email);
			if(optional.isPresent())
				return optional.get();
		} catch (Exception e) {
			System.out.println("in exception of getUserByEmail");
			System.out.println(e.getMessage());
		}
		return null;
	}


	@Override
	public User updatepwd(String email, String pwd) {
		System.out.println("in method of updatepwd of userservice "+email);
		try {
			Optional<User> optional=userRepo.findByEmail(email);
			if(optional.isPresent())
			{
				User u=optional.get();
				u.setPwd(pwd);
				return userRepo.save(u);
			}
				
		} catch (Exception e) {
			System.out.println("in exception of updatepwd");
			System.out.println(e.getMessage());
		}
		return null;
	}

	


	

	@Override
	public User uploadPhoto(UUID id, String fileName) {
		System.out.println("in method of uploadPhoto of userservice ");
		try {
			Optional<User> optional=userRepo.findBySerialNo(id);
			if(optional.isPresent()) {
				User u=optional.get();
			    u.setUserImage(fileName);
				return userRepo.save(u);
			}
		} catch (Exception e) {
			System.out.println("in exception of uploadPhoto");
			System.out.println(e.getMessage());
		}
		return null;
	}


	@Override
	public User getUserBySerialNo(UUID serialNo) {
		System.out.println("in method of getUserBySerialNo of userservice "+serialNo);
		try {
			Optional<User> optional=userRepo.findBySerialNo(serialNo);
			if(optional.isPresent())
				return optional.get();
		} catch (Exception e) {
			System.out.println("in exception of getUserBySerialNo");
			System.out.println(e.getMessage());
		}
		return null;
	}


	@Override
	public User updateProfile(User u,UUID serialNo) {
		System.out.println("in method of updateProfile of userservice "+serialNo);
		try {
			Optional<User> optional=userRepo.findBySerialNo(serialNo);
			if(optional.isPresent()) {
				User user=optional.get();
				user.getAddr().setBuildingName(u.getAddr().getBuildingName());
				user.getAddr().setColonyName(u.getAddr().getColonyName());
				user.getAddr().setCity(u.getAddr().getCity());
				user.getAddr().setPincode(u.getAddr().getPincode());
				user.getAddr().setState(u.getAddr().getState());
				user.setPhone(u.getPhone());
				return userRepo.save(user);
			}
				
			
		} catch (Exception e) {
			System.out.println("in exception of getUserBySerialNo");
			System.out.println(e.getMessage());
		}
		return null;
	}


	@Override
	public User updateUser(User u) {
		System.out.println("in method of updateUser of userservice "+u.getEmail());

		try {
			return userRepo.save(u);
		} catch ( Exception e) {
			System.out.println("in exception of updateUser");
			System.out.println(e.getMessage());
		}
		return null;
	}



}
