package com.example.demo.pojos;

public enum ProductUse {
BATHROOM,LIVINGROOM,KITCHEN,OUTDOOR,COMMERCIALSPACES
}
