package com.example.demo.controller.shop;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Blob;
import java.util.UUID;

import javax.mail.internet.MimeMessage;
import javax.sql.rowset.serial.SerialBlob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


import com.example.demo.dto.Email_UUID_dto;
import com.example.demo.dto.Otp_Pass_Dto;
import com.example.demo.dto.ResultDto;
import com.example.demo.dto.userDto;
import com.example.demo.pojos.Address;
import com.example.demo.pojos.Role;
import com.example.demo.pojos.User;
import com.example.demo.service.UserServiceImpl;
import com.example.demo.utils.UserUtils;


@RestController
@CrossOrigin("http://localhost:3070")
@RequestMapping("/shop-keeper")
public class ShopkeeperController {
	@Autowired
	UserServiceImpl userServiceImpl;
	
	@Autowired
	private JavaMailSender emailSender;
	
	String location ="D:\\premium tiles collection edac project\\Images\\shopkeeper";
	
	int otp;
	public ShopkeeperController() {
		System.out.println("in constructor of"+getClass().getName());
	}
	
	
	@PostMapping("/signup")
	public ResponseEntity<?> addUser(@RequestBody userDto uDto){
		System.out.println("in sign up function of " + uDto);
	ResultDto result=new ResultDto("error","something went wrong");
		try {
			Address addr = new Address(uDto.getBuildingName(), uDto.getColonyName(), uDto.getCity(), uDto.getState(),
					uDto.getPincode());
			User u = new User(uDto.getFirstName(), uDto.getLastName(),uDto.getphone(), uDto.getEmail(), uDto.getPwd(),
					uDto.getBirthDate());
			u.addAddress(addr);
			u.setRole(Role.SHOPKEEPER);
			u = userServiceImpl.addUser(u);
			
			if (u != null) {
				result.setStatus("success");
				result.setData(u);
				
			}
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception in addUser  of "+getClass().getName());
			System.out.println(e.getMessage());
			return ResponseEntity.ok(result);
		}
		return ResponseEntity.ok(result);
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody userDto user) {
		System.out.println("in login function of "+getClass().getName()+" "+user.getEmail());
		ResultDto result=new ResultDto("error","something went wrong");
		try {
			User u=userServiceImpl.getUserByEmailAndPwd(user.getEmail(),user.getPwd());
			if(u!=null) {
				if(u.getRole().name().compareTo("SHOPKEEPER")!=0) {
					result.setData("u r not authorised to login");
				}else {
					result.setStatus("success");
					result.setData(u);
				}
			}else {
				result.setData("invalid username and password");
			}
			
			
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception in loginUser  of "+getClass().getName());
			System.out.println(e.getMessage());
			return ResponseEntity.ok(result);
		}
			
			
		return ResponseEntity.ok(result);
	}
	
	@PostMapping("/get-profile")
	public ResponseEntity<?> getProfile(@RequestBody Email_UUID_dto email_UUID_dto) {
		System.out.println("in getProfile function of "+getClass().getName()+" "+email_UUID_dto.getSerialNo());
		ResultDto result=new ResultDto("error","something went wrong");
		try {
			User u=userServiceImpl.getUserBySerialNo(email_UUID_dto.getSerialNo());
			if(u!=null) {
				result.setStatus("success");
				result.setData(u);
			}
			
			
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception in getProfile  of "+getClass().getName());
			System.out.println(e.getMessage());
			return ResponseEntity.ok(result);
		}
			
			
		return ResponseEntity.ok(result);
	}
	
	
	@PostMapping("/image-upload")
	public ResponseEntity<?> imageUpload(@RequestHeader UUID id, @RequestBody MultipartFile file) throws Exception {

		
		System.out.println("in image uploading function of " + getClass().getName()+" "+file.getOriginalFilename());
		ResultDto result=new ResultDto("error","something went wrong while uploading image");
		try {
			System.out.println("file name "+file.getOriginalFilename());
			String fileName=file.getOriginalFilename();
			Path path = Paths.get(location, file.getOriginalFilename());
			
			File temp=new File(path.toString());
			System.out.println(temp.exists());
			while(temp.exists() ) {
				String name=file.getOriginalFilename();
				int index=name.indexOf('.');
				int max=10000,min=99999;
				int b = (int)(Math.random()*(max-min+1)+min);  
				int c = (int)(Math.random()*(max-min+1)+min);  
				 fileName=name.substring(0,index)+b+c+name.substring(index);
				 System.out.println("filename "+fileName);
				path = Paths.get(location, fileName);
				temp=new File(path.toString());
			}
			
			User u=userServiceImpl.uploadPhoto(id, fileName);
			if(u!=null) {
				file.transferTo(new File(location, u.getUserImage()));
				result.setData("image uploaded successfully");
				result.setStatus("success");
			}
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception in imageUpload  of "+getClass().getName());
			System.out.println(e.getLocalizedMessage());
		}
		return ResponseEntity.ok(result);
	}
	
	@PutMapping("/image-download")
	public ResponseEntity<?> imageDownload(@RequestBody Email_UUID_dto email_UUID_dto) throws Exception {
		ResultDto result=new ResultDto("error","something went wrong");
		System.out.println("in image downloading function of " +getClass().getName()+" "+email_UUID_dto.getEmail());
		try {
			User u = userServiceImpl.getUserBySerialNo(email_UUID_dto.getSerialNo());
			if (u != null ) {
				Path  path;
			if(u.getUserImage()!=null) {
				path = Paths.get(location, u.getUserImage());
				File temp=new File(path.toString());
				if(temp.exists()) {
					path = Paths.get(location, u.getUserImage());
					
				}else {
					 path = Paths.get(location, "user_dummy.png");
				}
			}else {
				 path = Paths.get(location, "user_dummy.png");
			}
				
				InputStreamResource input = new InputStreamResource(new FileInputStream(path.toFile()));
				ClassPathResource imageFile = new ClassPathResource(path.toString());
				byte[] imageBytes = org.springframework.util.StreamUtils.copyToByteArray(input.getInputStream());
				Blob blob = new SerialBlob(imageBytes);
				HttpHeaders headers = new HttpHeaders();
				headers.add("content-type", Files.probeContentType(path));
				return ResponseEntity.ok().header(HttpHeaders.CONTENT_TYPE, "image/*").body(blob);
			}else {
				result.setData("error:wrong librarian id");
			}
		} catch (Exception e) {
			result.setData("error:"+e.getMessage());
			System.out.println("exception in imageDownload  of "+getClass().getName());
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);
	}


	
	@PutMapping("/update-profile")
	public ResponseEntity<?> updateProfile(@RequestHeader UUID id,@RequestBody userDto uDto) throws Exception {
		System.out.println("in update user function of " + uDto.getEmail());
		System.out.println(uDto.toString());
		ResultDto result=new ResultDto("error","user not found");
		try {
			Address addr = new Address(uDto.getBuildingName(), uDto.getColonyName(), uDto.getCity(), uDto.getState(),
					uDto.getPincode());
			User u = new User(uDto.getFirstName(), uDto.getLastName(),uDto.getphone(), uDto.getEmail(), uDto.getPwd(),
					uDto.getBirthDate());
			u.setAddr(addr);
			u=userServiceImpl.updateProfile(u, id);
			if (u != null) {
				result.setStatus("success");
				result.setData(u);
			}
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception in updateProfile  of "+getClass().getName());
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);
	}
	
	
	@PutMapping("/forget-password")
	public ResponseEntity<?> forget_passwod_otp(@RequestBody Email_UUID_dto email)  {
		String pathToAttachment = "D:\\premium tiles collection edac project\\Template\\forget_password1.html";
		System.out.println("in forget password method of  " + email.getEmail());
		ResultDto result = new ResultDto("error","user not found with that email");
		try {
			User u=userServiceImpl.getUserByEmail(email.getEmail());
			if(u!=null) {
				File file = new File(pathToAttachment);
			     u = userServiceImpl.getUserByEmail(email.getEmail());
				System.out.println(u);
				
				if (u != null) {
					BufferedReader reader = new BufferedReader(new FileReader(file));
					String line = reader.readLine();
					String content = "";
					this.otp =UserUtils.generateOTP();
					String otpNumber = String.valueOf(this.otp);
					while (line != null) {
						content = content + line + System.lineSeparator();

						line = reader.readLine();
					}
					reader.close();
					content = content.replaceAll("otpNumber", otpNumber);
					MimeMessage message = emailSender.createMimeMessage();

					MimeMessageHelper helper = new MimeMessageHelper(message, true);

					helper.setFrom("shrinath658@gmail.com");
					helper.setTo(u.getEmail());
					helper.setSubject("otp to reset password");
					helper.setText(content, true);
					helper.addInline("welcomeImage",
							new File("D:\\premium tiles collection edac project\\Template\\welcome.jpg"));
					emailSender.send(message);
					result.setStatus("success");
					result.setData(otpNumber);
					

				}
			}else {
				result.setData("wrong email id");
			}
		
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception in forget_passwod_otp  of "+getClass().getName());
			System.out.println(e.getMessage());
		} 
		return  ResponseEntity.ok(result);
	}
	
	
	@PutMapping("/update-password")
	public ResponseEntity<?> updatePassword(@RequestBody Otp_Pass_Dto user){
		System.out.println("in update password  of "+user.getEmail()+" "+user.getPwd());
		ResultDto result=new ResultDto("error","user not found associate with email");
		if(otp == user.getOtp()) {
			try {
				User u=userServiceImpl.getUserByEmail(user.getEmail());
				if(u!=null) {
					u=userServiceImpl.updatepwd(user.getEmail(), user.getPwd());
					if(u!=null) {
						result.setData(u);
						result.setStatus("success");
					}
				}else {
					result.setData("wrong email id");
				}
			} catch (Exception e) {
				result.setData(e.getMessage());
				System.out.println("exception in updatePassword  of "+getClass().getName());
				System.out.println(e.getMessage());
			}
		}else {
			result.setData("wrong otp please reenter");
			
		}
		return ResponseEntity.ok(result);
	}

	
	
}
