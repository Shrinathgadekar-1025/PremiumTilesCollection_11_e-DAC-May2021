package com.example.demo.dto;

import java.sql.Blob;

import com.example.demo.pojos.Cart;

public class Cart_Result_Data_dto {
private Cart cart;
private Blob blob;
public Cart_Result_Data_dto(Cart cart, Blob blob) {
	super();
	System.out.println("in ctor of Cart_Result_Data_dto");
	this.cart = cart;
	this.blob = blob;
}
public Cart_Result_Data_dto() {
	super();
	System.out.println("in ctor of Cart_Result_Data_dto");
}
public Cart getCart() {
	return cart;
}
public void setCart(Cart cart) {
	this.cart = cart;
}
public Blob getBlob() {
	return blob;
}
public void setBlob(Blob blob) {
	this.blob = blob;
}
@Override
public String toString() {
	return "Cart_Result_Data_dto [cart=" + cart + "]";
}


}
