package com.example.demo.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "cart_tbl")
@JsonInclude(Include.NON_DEFAULT)
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonProperty("id")
	private int cartId;
	
	private int count=0;
	
	private boolean isOrdered=false;
	
	private boolean isDelivered=false;
	
	private boolean isCustomized=false;
	
	private boolean isAccepted=false;
	@JsonManagedReference
	@ManyToOne
	@JoinColumn(name="userId",nullable = false)
	private User user;
	
	@JsonManagedReference
	@ManyToOne
	@JoinColumn(name="tilesId",nullable = false)
	private Tiles tile;

	public Cart() {
		super();
		System.out.println("in constructor of cart");
	}



	public int getCartId() {
		return cartId;
	}



	public void setCartId(int cartId) {
		this.cartId = cartId;
	}



	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	

	public boolean isOrdered() {
		return isOrdered;
	}



	public void setOrdered(boolean isOrdered) {
		this.isOrdered = isOrdered;
	}



	public boolean isDelivered() {
		return isDelivered;
	}



	public void setDelivered(boolean isDelivered) {
		this.isDelivered = isDelivered;
	}



	public boolean isCustomized() {
		return isCustomized;
	}



	public void setCustomized(boolean isCustomized) {
		this.isCustomized = isCustomized;
	}

	


	public boolean isAccepted() {
		return isAccepted;
	}



	public void setAccepted(boolean isAccepted) {
		this.isAccepted = isAccepted;
	}



	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Tiles getTile() {
		return tile;
	}

	public void setTile(Tiles tile) {
		this.tile = tile;
	}



	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", count=" + count + ", isOrdered=" + isOrdered + ", isDelivered="
				+ isDelivered + ", isCustomized=" + isCustomized + ", isAccepted=" + isAccepted + ", user=" + user
				+ ", tile=" + tile + "]";
	}



	


	
	
}
