package com.example.demo.pojos;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@Entity
@Table(name = "user_tbl")
@JsonInclude(Include.NON_DEFAULT)
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonProperty("id")
	private int userId;
	@Column(name = "serial_no",unique = true,columnDefinition = "BINARY(16)",nullable = false)
	private UUID serialNo=UUID.randomUUID();
	@Column(name = "first_name", length = 40)
	private String firstName;
	@Column(name = "last_name", length = 40)
	private String lastName;
	@Column(name = "email", length = 40,unique=true)
	private String email;
	@Column(name = "phone", length = 10,unique=true)
	private String phone;
	@Column(name="password",length=20)
	private String pwd;
	@Column(name="birth_date")
	private LocalDate birthdate;
	//@Column(name="created_timestamp",columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP",updatable = false,insertable = false)
	@Column(name="created_on")
	@JsonProperty("createdOn")
	private Timestamp current_timestamp=new Timestamp(System.currentTimeMillis());
	@Column(name="image",length=100)
	private  String userImage;
	@Column(name="role")
	@Enumerated(EnumType.STRING)
	private Role role;
	private double fine=0;
	private boolean isEmail=false;
	@JsonManagedReference
	@OneToOne(mappedBy = "user",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private Address addr;
	@JsonIgnore
	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private List<Tiles> tiles=new ArrayList<Tiles>();
	@JsonIgnore
	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private List<Cart> carts =new ArrayList<Cart>();
	public User(){
		System.out.println("in ctor of "+getClass().getName());
	}
	
	
	public User(String firstName, String lastName, String phone, String email, String pwd, LocalDate birthdate) {

		super();
		System.out.println("in parameterised ctor of "+getClass().getName());
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone=phone;
		this.email = email;
		this.pwd = pwd;
		this.birthdate = birthdate;
	}
	
	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public UUID getSerialNo() {
		return serialNo;
	}


	public void setSerialNo(UUID serialNo) {
		this.serialNo = serialNo;
	}





	public void setEmail(boolean isEmail) {
		this.isEmail = isEmail;
	}



	


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getPwd() {
		return pwd;
	}


	public void setPwd(String pwd) {
		this.pwd = pwd;
	}


	public LocalDate getBirthdate() {
		return birthdate;
	}


	public void setBirthdate(LocalDate birthdate) {
		this.birthdate = birthdate;
	}


	public Timestamp getCurrent_timestamp() {
		return current_timestamp;
	}


	public void setCurrent_timestamp(Timestamp current_timestamp) {
		this.current_timestamp = current_timestamp;
	}


	public String getUserImage() {
		return userImage;
	}


	public void setUserImage(String userImage) {
		this.userImage = userImage;
	}
	
	



	public Role getRole() {
		return role;
	}


	public void setRole(Role role) {
		this.role = role;
	}


	


	public double getFine() {
		return fine;
	}


	public void setFine(double fine) {
		this.fine = fine;
	}


	public boolean getIsEmail() {
		return isEmail;
	}


	public void setIsEmail(boolean isEmail) {
		this.isEmail = isEmail;
	}


	public Address getAddr() {
		return addr;
	}


	public void setAddr(Address addr) {
		this.addr = addr;
	}

	public void addAddress(Address addr) {
		this.addr=addr;
		addr.setUser(this);
	}
	
	public void removeAddress() {
		this.addr.setUser(null);
		this.addr=null;
	}


	public List<Tiles> getTiles() {
		return tiles;
	}


	public void setTiles(List<Tiles> tiles) {
		this.tiles = tiles;
	}


	public void addTile(Tiles t) {
		this.tiles.add(t);
		t.setUser(this);
	}
	
	
	public void removeTile(Tiles t) {
		this.tiles.remove(t);
		t.setUser(null);
	}
	
	
	
	public List<Cart> getCarts() {
		return carts;
	}


	public void setCarts(List<Cart> carts) {
		this.carts = carts;
	}


	public void AddToCart(Cart c) {
		this.carts.add(c);
		c.setUser(this);
	}
	
	public void RemoveCart(Cart c) {
		this.carts.remove(c);
		c.setUser(null);
	}
	
	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", serialNo=" + serialNo + ", firstName=" + firstName + ", lastName="
				+ lastName + ", email=" + email + ", phone=" + phone + ", pwd=" + pwd + ", birthdate=" + birthdate
				+ ", current_timestamp=" + current_timestamp + ", userImage=" + userImage + ", role=" + role + ", fine="
				+ fine + ", isEmail=" + isEmail + ", addr=" + addr + "]";
	}
	
	
	

}
