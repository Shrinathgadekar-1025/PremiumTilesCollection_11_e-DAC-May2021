package com.example.demo.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.pojos.Cart;
import com.example.demo.pojos.User;

public interface CartRepository extends JpaRepository<Cart, Integer> {
Optional<List<Cart>> findByUserAndIsOrdered(User u,boolean isOrdered);
Optional<Cart> findByCartId(int id);
@Query("select c from Cart c where c.isOrdered = ?1 and c.isDelivered=?2")
Optional<List<Cart>> finByisOrderedAndisDelivered(boolean isOrdered,boolean isDelivered);
@Query("select c from Cart c where c.isCustomized = ?1 and c.isAccepted=?2")
Optional<List<Cart>> findByisCustomizedAndisAccepted(boolean isCustomized,boolean isAccepted);

}
