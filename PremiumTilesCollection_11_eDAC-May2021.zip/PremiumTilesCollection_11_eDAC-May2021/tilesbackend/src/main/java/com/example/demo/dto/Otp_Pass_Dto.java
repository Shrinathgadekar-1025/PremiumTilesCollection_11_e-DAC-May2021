package com.example.demo.dto;

public class Otp_Pass_Dto {
private int otp;
private String pwd;
private String email;
public Otp_Pass_Dto() {
	super();
}
public Otp_Pass_Dto(int otp, String pwd, String email) {
	super();
	this.otp = otp;
	this.pwd = pwd;
	this.email = email;
}
public int getOtp() {
	return otp;
}
public void setOtp(int otp) {
	this.otp = otp;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
@Override
public String toString() {
	return "Otp_Pass_Dto [otp=" + otp + ", pwd=" + pwd + ", email=" + email + "]";
}

}
