package com.example.demo.pojos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name = "tiles_tbl")
@JsonInclude(Include.NON_DEFAULT)
public class Tiles {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonProperty("id")
	private int tilesId;
	@Column(name = "serial_no",unique = true,columnDefinition = "BINARY(16)",nullable = false)
	private UUID serialNo=UUID.randomUUID();
	@Column(name = "tilesName",unique = true)
	private String tilesName;
	@Column(name="tilesImage")
	private  String tilesImage;
	@Column(name="productBase")
	@Enumerated(EnumType.STRING)
	private  ProductBase productBase;
	@Column(name="productType")
	@Enumerated(EnumType.STRING)
	private  ProductTypes productType;
	@Column(name="productUse")
	@Enumerated(EnumType.STRING)
	private  ProductUse productUse;
	@Column(name="productSize")
	private String productSize;
	@Column(name="productFinishing")
	private String productFinishing;
	@Column(name="productMaterial")
	@Enumerated(EnumType.STRING)
	private Material productMaterial;
	private LocalDate createdOn=LocalDate.now();
	private double price=0;
	@JsonBackReference
	@ManyToOne
	@JoinColumn(name="userId",nullable = true)
	private User user;

	@JsonIgnore
	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private List<Cart> carts =new ArrayList<Cart>();
	
	public Tiles() {
		super();
		System.out.println("in ctor of tiles");
	}
	public Tiles(String tilesName, String tilesImage, ProductBase productBase, ProductTypes productType,
			ProductUse productUse, String productSize, String productFinishing, Material productMaterial) {
		super();
		System.out.println("in ctor of tiles");
		this.tilesName = tilesName;
		this.tilesImage = tilesImage;
		this.productBase = productBase;
		this.productType = productType;
		this.productUse = productUse;
		this.productSize = productSize;
		this.productFinishing = productFinishing;
		this.productMaterial = productMaterial;
	}
	
	
	public Tiles(String tilesName, String tilesImage, ProductBase productBase, ProductTypes productType,
			ProductUse productUse, String productSize, String productFinishing, Material productMaterial,
			double price) {
		super();
		System.out.println("in ctor of tiles");
		this.tilesName = tilesName;
		this.tilesImage = tilesImage;
		this.productBase = productBase;
		this.productType = productType;
		this.productUse = productUse;
		this.productSize = productSize;
		this.productFinishing = productFinishing;
		this.productMaterial = productMaterial;
		this.price = price;
	}
	public int getTilesId() {
		return tilesId;
	}
	public void setTilesId(int tilesId) {
		this.tilesId = tilesId;
	}
	public UUID getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(UUID serialNo) {
		this.serialNo = serialNo;
	}
	public String getTilesName() {
		return tilesName;
	}
	public void setTilesName(String tilesName) {
		this.tilesName = tilesName;
	}
	public String getTilesImage() {
		return tilesImage;
	}
	public void setTilesImage(String tilesImage) {
		this.tilesImage = tilesImage;
	}
	public ProductBase getProductBase() {
		return productBase;
	}
	public void setProductBase(ProductBase productBase) {
		this.productBase = productBase;
	}
	public ProductTypes getProductType() {
		return productType;
	}
	public void setProductType(ProductTypes productType) {
		this.productType = productType;
	}
	public ProductUse getProductUse() {
		return productUse;
	}
	public void setProductUse(ProductUse productUse) {
		this.productUse = productUse;
	}
	public String getProductSize() {
		return productSize;
	}
	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	public String getProductFinishing() {
		return productFinishing;
	}
	public void setProductFinishing(String productFinishing) {
		this.productFinishing = productFinishing;
	}
	public Material getProductMaterial() {
		return productMaterial;
	}
	public void setProductMaterial(Material productMaterial) {
		this.productMaterial = productMaterial;
	}
	
	
	
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	public LocalDate getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(LocalDate createdOn) {
		this.createdOn = createdOn;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	public List<Cart> getCarts() {
		return carts;
	}


	public void setCarts(List<Cart> carts) {
		this.carts = carts;
	}


	public void AddToCart(Cart c) {
		this.carts.add(c);
		c.setTile(this);
	}
	
	public void RemoveCart(Cart c) {
		this.carts.remove(c);
		c.setTile(null);
	}
	@Override
	public String toString() {
		return "Tiles [tilesId=" + tilesId + ", serialNo=" + serialNo + ", tilesName=" + tilesName + ", tilesImage="
				+ tilesImage + ", productBase=" + productBase + ", productType=" + productType + ", productUse="
				+ productUse + ", productSize=" + productSize + ", productFinishing=" + productFinishing
				+ ", productMaterial=" + productMaterial + ", createdOn=" + createdOn + ", price=" + price + "]";
	}
	
	

	
	
	
	
}
