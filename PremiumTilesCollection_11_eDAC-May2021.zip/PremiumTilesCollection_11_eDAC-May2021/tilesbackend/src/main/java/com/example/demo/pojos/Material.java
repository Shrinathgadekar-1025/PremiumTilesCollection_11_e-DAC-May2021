package com.example.demo.pojos;

public enum Material {
	GLAZEDVITRIFIED,CERAMIC,POLISHEDVITRIFIED
}
