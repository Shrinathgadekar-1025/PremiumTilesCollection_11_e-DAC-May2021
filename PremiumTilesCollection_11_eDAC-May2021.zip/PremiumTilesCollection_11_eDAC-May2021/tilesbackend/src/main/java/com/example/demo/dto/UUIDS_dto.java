package com.example.demo.dto;

import java.util.UUID;

public class UUIDS_dto {
private UUID uSerialNo;
private UUID pSerialNo;

public UUIDS_dto() {
	System.out.println("in ctor of UUIDS_dto");
}

public UUID getuSerialNo() {
	return uSerialNo;
}

public void setuSerialNo(UUID uSerialNo) {
	this.uSerialNo = uSerialNo;
}

public UUID getpSerialNo() {
	return pSerialNo;
}

public void setpSerialNo(UUID pSerialNo) {
	this.pSerialNo = pSerialNo;
}

@Override
public String toString() {
	return "UUIDS_dto [uSerialNo=" + uSerialNo + ", pSerialNo=" + pSerialNo + "]";
}

}
