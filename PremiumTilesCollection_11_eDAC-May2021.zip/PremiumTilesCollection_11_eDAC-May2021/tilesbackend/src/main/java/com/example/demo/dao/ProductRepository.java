package com.example.demo.dao;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.pojos.Material;
import com.example.demo.pojos.ProductBase;
import com.example.demo.pojos.ProductTypes;
import com.example.demo.pojos.Tiles;



public interface ProductRepository extends JpaRepository<Tiles,Integer> {
Optional<Tiles> findBySerialNo(UUID id);
Optional<List<Tiles>> findByProductType(ProductTypes type);
Optional<List<Tiles>> findByProductTypeAndProductBase(ProductTypes type,ProductBase base);
Optional<List<Tiles>> findByProductMaterial(Material mat);
Optional<Tiles> findByTilesName(String name);
@Query(value="select * from tiles_tbl order by created_on desc limit 10",nativeQuery = true)
Optional<List<Tiles>> findFirstTen();
long deleteBySerialNo(UUID id);
}

