package com.example.demo.controller.user;

import java.sql.Blob;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.ResultDto;
import com.example.demo.dto.Tiles_Result_Data_dto;
import com.example.demo.pojos.Tiles;
import com.example.demo.service.ProductServiceImpl;
import com.example.demo.utils.UserUtils;

@RestController
@CrossOrigin("http://localhost:3080")
@RequestMapping("/user/home")
public class UserHomeController {
	@Autowired
	private ProductServiceImpl productServiceImpl;
	
	public UserHomeController() {
		System.out.println("in ctor of HomeContorller");
	}
	String location = "D:\\premium tiles collection edac project\\Images\\Tiles";

	@GetMapping("/get_products")
	public ResponseEntity<?> getProducts(){
		System.out.println("in homecontroller");
		ResultDto result = new ResultDto("error", "something went wrong");
		try {
			List<Tiles>tiles=productServiceImpl.fetchLatestTiles();
			if(tiles!=null) {
				List<Tiles_Result_Data_dto> resultData = new ArrayList<Tiles_Result_Data_dto>();
				for (Tiles tile:tiles) {
					Blob blob = UserUtils.GetImage(location, tile.getTilesImage(), "user_dummy.png");
					if (blob != null) {
						resultData.add(new Tiles_Result_Data_dto(tile, blob));
					}

				}
				result.setData(resultData);
				result.setStatus("success");
			}
		} catch (Exception e) {
			result.setData(e.getMessage());
			System.out.println("exception caught in getProducts function of HomeController");
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(result);
	}
}
