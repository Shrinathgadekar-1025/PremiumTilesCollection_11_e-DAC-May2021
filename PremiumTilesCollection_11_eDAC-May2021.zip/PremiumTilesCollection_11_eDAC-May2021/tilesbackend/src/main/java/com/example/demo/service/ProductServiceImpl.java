package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.ProductRepository;
import com.example.demo.dao.UserRepository;
import com.example.demo.pojos.Material;
import com.example.demo.pojos.ProductTypes;
import com.example.demo.pojos.Tiles;
import com.example.demo.pojos.User;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	private ProductRepository productRepository;
	
	
	@Autowired
	private UserRepository userRepository;
	
	public ProductServiceImpl() {
		System.out.println("in the constructor of "+getClass().getName());
	}

	@Override
	public Tiles addTile(Tiles t) {
		System.out.println("in addTile method of ProductServiceImpl"+t.getTilesName());
		try {
			return productRepository.save(t);
		} catch (Exception e) {
			System.out.println("exception caught in addTiles");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public Tiles getBySerialNo(UUID id) {
		System.out.println("in findBySerialNo method of ProductServiceImpl"+id);
		try {
			Optional<Tiles> optional=productRepository.findBySerialNo(id);
			if(optional.isPresent()) {
				return optional.get();
			}
		} catch (Exception e) {
			System.out.println("exception caught in getBySerialNo");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public Tiles uploadPhoto(UUID id, String image) {
		System.out.println("in findBySerialNo method of ProductServiceImpl"+id);
		try {
			Optional<Tiles> optional=productRepository.findBySerialNo(id);
			if(optional.isPresent()) {
				Tiles t= optional.get();
				t.setTilesImage(image);
				return productRepository.save(t);
			}
		} catch (Exception e) {
			System.out.println("exception caught in uploadPhoto");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public List<Tiles> GetTilesByType(ProductTypes type) {
		System.out.println("in GetTypes method of ProductServiceImpl"+type);
		try {
			Optional<List<Tiles>> optional=productRepository.findByProductType(type);
			if(optional.isPresent()) {
				return optional.get();
			}
		} catch (Exception e) {
			System.out.println("exception caught in uploadPhoto");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public List<Tiles> GetTilesByMaterial(Material mat) {
		System.out.println("in GetTilesByMaterial method of ProductServiceImpl"+mat);
		try {
			Optional<List<Tiles>> optional=productRepository.findByProductMaterial(mat);
			if(optional.isPresent()) {
				return optional.get();
			}
		} catch (Exception e) {
			System.out.println("exception caught in GetTilesByMaterial");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public Tiles addCustomizedTile(Tiles t,UUID id) {
		System.out.println("in addCustomizedTile method of ProductServiceImpl"+t.getTilesName());
		try {
		Optional<User> optional=userRepository.findBySerialNo(id);
		if(optional.isPresent()) {
			User u=optional.get();
			u.addTile(t);
		User user=	userRepository.save(u);
		for (Tiles tile : user.getTiles()) {
			if(tile.getTilesName().compareTo(t.getTilesName())==0) {
				return tile;
			}
		}
			
		}
		} catch (Exception e) {
			System.out.println("exception caught in addCustomizedTile");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public Tiles getByTilesName(String name) {
		System.out.println("in getByTilesName method of ProductServiceImpl "+name);
		try {
			Optional<Tiles> optional=productRepository.findByTilesName(name);
			if(optional.isPresent()) {
				return optional.get();
			}
		} catch (Exception e) {
			System.out.println("exception caught in getByTilesName");
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public long deleteTilesBySerialNo(UUID id) {
		System.out.println("in deleteTilesBySerialNo method of ProductServiceImpl "+id);
		long res=0;
		try {
			 res=productRepository.deleteBySerialNo(id);
			
		} catch (Exception e) {
			System.out.println("exception caught in deleteTilesBySerialNo");
			System.out.println(e.getMessage());
		}
		return res;
	}

	@Override
	public List<Tiles> fetchLatestTiles() {
		System.out.println("in fetchLatestTiles method of ProductServiceImpl ");
		try {
			Optional<List<Tiles>>tiles=productRepository.findFirstTen();
			if(tiles.isPresent()) {
				return tiles.get();
			}
		} catch (Exception e) {
			System.out.println("exception caught in fetchLatestTiles");
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	
	
	
}
